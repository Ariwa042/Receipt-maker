Please add the First Bank logo here as 'firstbank-logo.png'.
You can get the official First Bank logo from their brand resources or use a properly licensed version.

The logo should be:
- High resolution
- Transparent background (PNG format)
- Official First Bank blue color (#003b65)
- Named exactly as 'firstbank-logo.png'
